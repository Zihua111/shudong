<template>
	<view>
		<view>
			<view class="line">
				<view>d = </view><input v-model="d" />
				<view>mm</view>
			</view>
			<view class="line">
				<view>b = </view><input v-model="b" />
				<view>mm</view>
			</view>

			<view class="line">
				<view>fck = </view><input v-model="fck" />
				<view>MPa</view>
			</view>
		</view>
		
		<view></view>
		<view></view>
		<view class="sectionA">
			<view>已知Med求K，Z</view>
			<view class="line">
				<view>输入Med</view><input v-model="sectionA.Med" />

			</view>
			<view class="line">
				<view>K = {{sectionA_K}}</view>
				<view>z = {{sectionA_Z}} mm</view>
				<view>As = {{sectionA_As}}</view>
			</view>
		</view>
		<view></view>
		<view></view>
		<view class="sectionB">
			<view>已知steel求Med,  analysis</view>
			<view class="line">
				<input v-model="sectionB.topnumber"/><view>  H  </view><input v-model="sectionB.topdiameter" /><view>距离</view><input v-model="sectionB.d2" />
			</view>
			<view class="line">
				<input v-model="sectionB.bottomnumber"/><view>  H  </view><input v-model="sectionB.bottomdiameter" />
			</view>
			<view class="line">
				Mrd = {{sectionB_M}}
			</view>
		</view>
		<view></view>
		<view></view>
		<view class="sectionC">
			<view class="line">K’ = 0.207</view>
			<view class="line">
				<view> Med = </view><input v-model="sectionC.Med"/>
			</view>
			<view class="line">
				<view>d2  = </view><input v-model="sectionC.d2" />
			</view>
			<view class="line">com As2 = {{sectionC_As2}}</view>
			<view class="line">ten As = {{sectionC_As}}</view>
		</view>
		<view></view>
		<view></view>
<!-- <view class="sectionD">
	TOP，0.6，求As：：：：：：66666
	<view class="line">
		<input v-model="sectionD.topnumber"/><view>  H  </view><input v-model="sectionD.topdiameter" /><view>距离</view><input v-model="sectionD.d2" />
	</view>
	<view> As bottom = {{sectionD_As}}</view>
</view> -->
<!-- <test></test> -->
<stafflogin></stafflogin>
	</view>
</template>

<script>
	import test from '@/components/yaoyao-request-test.vue'
	import stafflogin from '@/components/staffLogin/staffLogin.vue'
	export default {
		components:{
			test,
			stafflogin,
		},
		data() {
			return {
				b: "",
				d: "",
				fck: "",
				sectionA: {
					Med: "",
					K: "",
					Z: "",
					x: "",
					As:"",
					As2:"",
					d2:"",
				},
				sectionB:{
					topnumber:0,
					topdiameter:0,
					d2:"",
					
					bottomnumber:0,
					bottomdiameter:0,
				},
				sectionC:{
					Med:"",
					d2:"",
				},
				sectionD:{
					topnumber:0,
					topdiameter:0,
					d2:"",
					
					bottomnumber:0,
					bottomdiameter:0,
				},
			}
		},
		computed: {
			sectionA_K() {
				var res = this.sectionA.Med / (this.b * this.d * this.d * this.fck)*1000000;
				return res;
			},
			sectionA_Z() {
				if (this.sectionA_K > 0.206 || this.sectionA_K == undefined) {
					return 'K超了';
				};
				return this.d * (0.5 + Math.sqrt(0.25 - this.sectionA_K/1.134));
			},
			// sectionA_Mrd(){
			// 	var x = (this.d - this.sectionA_Z)/0.4;
			// 	return 0.567*this.fck*this.b*0.8*x*this.sectionA_Z;
			// },
			sectionA_As(){
				return this.sectionA.Med*1000000/(0.87*500*this.sectionA_Z);
			},
			//section B, analysis
			sectionB_M(){
				var As = this.sectionB.bottomdiameter*this.sectionB.bottomdiameter*Math.PI*this.sectionB.bottomnumber/4;
				var As2 = this.sectionB.topdiameter*this.sectionB.topdiameter*Math.PI*this.sectionB.topnumber/4;
				var Mtop = 0.87*500*As2*(this.d - this.sectionB.d2)/1000000;//kNm
				var x = (0.87*500*(As - As2))/(0.567*this.fck*this.b*0.8);//mm
				var Mbot = 0.87*500*(As - As2)*(this.d - 0.4*x)/1000000;//kNm
				var res = Mtop + Mbot;
				console.log(As, As2, Mtop,x,Mbot,res);
				return res;
				
			},
			
			//C
			sectionC_As2(){
				var Med = 0.207*this.b*this.d*this.d*this.fck/1000000;//kNm
				var Med2top = this.sectionC.Med - Med;
				var As2 = Med2top*1000000/(0.87*500*(this.d - this.sectionC.d2));
				return As2;
			},
			sectionC_As(){
				var Med = 0.207*this.b*this.d*this.d*this.fck/1000000;//kNm
				var Med2top = this.sectionC.Med - Med;
				var As2 = Med2top*1000000/(0.87*500*(this.d - this.sectionC.d2));
				var As1 = Med*1000000/(0.87*500*0.76*this.d);
				var res = As1 + As2;
				return res;
			},
			//
			//sectionD
			sectionD_As(){
				var As2 = this.sectionD.topdiameter*this.sectionD.topdiameter*Math.PI*this.sectionD.topnumber/4;
				var M = 0.567*this.fck*this.b*0.8*0.6*this.d/1000; //kNm
				var As = M*1000000/(0.87*500*0.76*this.d);
				var res = As + As2;
				console.log(As2, M ,As );
				return res;
			}
		},
		methods: {

		}
	}
</script>

<style scoped>
	view {
		border: 1px solid #4CD964;
	}

	.line {
		display: flex;
	}
</style>
