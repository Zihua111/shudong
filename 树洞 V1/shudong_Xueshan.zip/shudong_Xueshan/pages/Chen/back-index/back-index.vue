<!-- 
树洞后台主页
chen
2020/11/1
 -->


<template>
	<view class="wrapper" style="background-color: #000000;">
		<!-- 顶部区域 -->
		<!-- 顶部导航条 -->
		<uni-nav-bar shadow="false" background-color="#333333" fixed="true" status-bar="true">
			<!-- 搜索框 -->
			<uni-search-bar :radius="10" maxlength="50"></uni-search-bar>
		</uni-nav-bar>
		<!-- 登录 -->
		<staffLogin style="position: relative;z-index: 1;margin-bottom: 20px;" @staffInfo="getStaffInfo"></staffLogin>
		<view class="middleCard">
			<!-- 倒计时显示区域 -->
			<view class="timeDisplay">
				<view class="time">
					10
				</view>
				小时
				<view class="time">
					10
				</view>
				分后清空
			</view>
			<!-- 中间右方区域 -->
			<view class="timeOrHot">
				<view class="iconTime">

				</view>
				<view class="iconHot">

				</view>
			</view>
		</view>
		<!-- 卡片区域 -->
		<view class="mainContent" v-for="(info,index) in cardInfoList" key="index" >
			<backCard :cardInfo="info" :staffInfo="staffInfo"></backCard>
		</view>
	</view>

</template>

<script>
	import uniNavBar from "@/components/uni-nav-bar/uni-nav-bar.vue"; //顶部导航条
	import uniSearchBar from '@/components/uni-search-bar/uni-search-bar.vue'; //搜索卡片
	import backCard from '../../../components/Chen/backCard.vue'; //后台卡片
	import staffLogin from '../../../components/staffLogin/staffLogin.vue';//登录组件
	export default {
		data() {
			return {
				cardInfoList: [],//卡片列表
				userInfo: {},//用户信息
				staffInfo: {},//后台登录人员信息
				page:1,//当前加载页数
			}
		},
		components: {
			backCard,
			staffLogin,
			uniSearchBar,
			uniNavBar,
		},
		methods: {
			timestampToTime(timestamp) {
				let date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
				let D = date.getDate() + ' ';
				let h = date.getHours() + ':';
				let m = date.getMinutes();
				return {
					date: M + D,
					time: h + m
				};
			},
			// 获取数据
			getCardInfo() {
				var that = this;
				uni.request({
					url: that.$serverUrl + '/article/queryArticles',
					method: 'POST',
					data: {
						page: that.page,
						pageSize: '10',
						userId: that.userInfo.id,
						queryType: '0',
						orderType: '0',
						selectedTag: ""
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						console.log('success');
						console.log(res);
						var cardInfo = {};
						if (res.data.status == 200) {
							that.cardInfoList = that.cardInfoList.concat(res.data.data.rows);
						}
					},
					fail: res => {
						console.log("failed");
					}
				});
			},
			getStaffInfo(info) {
				console.log("父组件", info);
				this.staffInfo = info;
			},
		},
		mounted() {
			this.getCardInfo();
		},
		// 触底翻页
		onReachBottom(){
			this.page++;
			this.getCardInfo()
		}
	}
</script>

<style>
	/* 设置顶部框 */
	.topBarCard {
		width: 100%;
		height: 68px;
		display: flex;
		align-content: space-between;
		padding-top: 12px;
	}

	/* 搜索框样式 */
	.topBarCard>.searchBox {
		width: 250px;
		height: 34px;
		background: #FFFFFF;
		border-radius: 15px;
		margin-left: 10px;
	}

	/* 搜索图标 */
	.topBarCard>.searchCard>.searchButton {
		margin: 0 auto;
	}

	/* 信息图标样式 */
	.topBarCard>.messageBox {
		width: 87px;
		height: 34px;
		background: #7D7D7D;
		border-radius: 34px;
		margin-left: 20px;
	}

	.middleCard {
		display: flex;
		align-content: space-between;
		width: 90%;
		height: 50px;
		margin: 0 auto;
	}

	.middleCard>.timeDisplay {
		width: 50%;
		display: flex;
		height: 50px;
		/* 文字样式 */
		font-size: 11px;
		font-weight: bold;
		color: #FFFFFF;
		line-height: 38px;
		opacity: 0.8;
	}

	/* 设置显示倒计时 */
	.middleCard>.timeDisplay>.time {
		margin-bottom: 0px;
		width: 30%;
		height: 30px;
		background-image: linear-gradient(#000000, #626262);
		/* 文字样式 */
		font-size: 24px;
		font-weight: bold;
		color: #FFFFFF;
		line-height: 30px;
		opacity: 0.8;
	}

	/* 右侧选择栏：时间或者热度 */
	.timeOrHot {
		width: 80px;
		display: flex;
		height: 30px;
		margin-left: 65px;
	}

	/* 右侧按钮 */
	.middleCard>.timeOrHot>.iconTime {

		background-color: #DBA503;
		width: 40px;
		height: 100%;
	}

	.middleCard>.timeOrHot>.iconHot {
		background-color: #636363;
		width: 40px;
		height: 100%;
	}
</style>
