<!-- 
树洞项目主页
ChenXueshan
2020/10/28
 -->
<template>
	<view style="background-color: #000000;">
		<!-- 登录组件 -->
		<loginCard></loginCard>
		<!-- 顶部导航条 -->
		<uni-nav-bar shadow="false" background-color="#333333" fixed="true" status-bar="true">
			<!-- 搜索框 -->
			<uni-search-bar :radius="10" maxlength="50"></uni-search-bar>
		</uni-nav-bar>
		<!-- 轮播图 -->
		<view class="slideCard">
			<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
				<swiper-item>
					<view class="swiper-item"></view>
				</swiper-item>
				<swiper-item>
					<view class="swiper-item"></view>
				</swiper-item>
				<swiper-item>
					<view class="swiper-item"></view>
				</swiper-item>
			</swiper>

		</view>
		<view class="textLine">
			最新推送
		</view>
		<!-- 主要内容展示卡片区域 -->
		<view class="mainContent" v-for="(info,index) in cardInfoList" key="index">
			<contentCard :cardInfo="info">
			</contentCard>
		</view>
		<bottomCard></bottomCard>
	</view>
</template>

<script>
	import uniNavBar from "@/components/uni-nav-bar/uni-nav-bar.vue"; //顶部导航条
	import uniSearchBar from '@/components/uni-search-bar/uni-search-bar.vue'; //搜索卡片
	import contentCard from '../../../components/Chen/contentCard.vue'; //主页卡片
	import bottomCard from '../../../components/Chen/bottomCard.vue'; //底部卡片
	import loginCard from '../../../components/Chen/userLogin.vue'; //登录组件
	export default {

		data() {
			return {
				cardInfoList: [],//卡片信息
				userInfo: {},//用户信息
				userComment:{},//用户评论
				page: 1,//显示的页数
			}
		},
		components: {
			uniNavBar, //顶部导航条组件
			contentCard, //正文卡片组件
			bottomCard, //底部组件
			loginCard, //登录组件
			uniSearchBar, //搜索组件
		},
		created() {
			this.userInfo = this.getGlobalUserInfo();
		},
		onReady() {
			console.log("get user info")
		},
		methods: {
			// 修改时间格式
			timestampToTime(timestamp) {
				let date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
				let D = date.getDate() + ' ';
				let h = date.getHours() + ':';
				let m = date.getMinutes();
				return {
					date: M + D,
					time: h + m
				};
			},
			// 获取文章数据
			getCardInfo() {
				console.log("card");
				var that = this;
				uni.request({
					url: that.$serverUrl + '/article/queryArticles',
					method: 'POST',
					data: {
						page: that.page,
						pageSize: '10',
						userId: that.userId,
						queryType: '0',
						orderType: '0',
						selectedTag: ""
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						console.log('success');
						console.log(res);
						let cardInfo = {};
						list = composeObj(obj)
					},
					fail: res => {
						console.log("failed");
					}
				});
			},
			/**
			 * 拼接数据
			 * @param {Object} obj 请求回来的数据对象
			 */
			composeObj(obj){
				for (var i = 0; i < res.data.data.rows.length; ++i) {
					cardInfo = {
						"userImg": res.data.data.rows.faceImg,
						"userName": res.data.data.rows[i].nickname,
						"contentText": res.data.data.rows[i].articleContent,
						"timeDisplay": this.timestampToTime(res.data.data.rows[i].createDate).date + "" + this.timestampToTime(res.data
							.data.rows[i].createDate).time,
						"isAnswered": res.data.data.rows[i].commentNum,
						"targetId": res.data.data.rows[i].id,
					};
					this.cardInfoList.push(cardInfo);
				}
				return list;
			}
		},
		// 获取卡片信息
		mounted() {
			this.getCardInfo();
		},
		// 触底翻页
		onReachBottom(){
			this.page++;
			this.getCardInfo()
		}
	}
</script>

<style>
	/* 包裹滑块的外边框样式 */
	.slideCard {
		width: 90%;
		margin: 0 auto;
		background-color: #515151;
		border-radius: 10px;
		margin-bottom: 10px;
		margin-top: 20px;
	}

	/* 设置滑动图高度 */
	.slideCard>swiper {
		height: 187px;
	}

	/* 显示"最新推送"的提示文字 */
	.textLine {
		content: '最新推送';
		display: block;
		margin: 0 auto;
		margin-bottom: 10px;
		width: 90%;
		height: 10px;
		font-size: 13px;
		font-weight: bold;
		color: #FFFFFF;
		line-height: 10px;
		opacity: 0.8;
	}
</style>
