<template style="background-color: #000000;">
	<view>
		<input type="text" v-model="searchKeyWords" @confirm="submit" focus="true" style="background-color: #bfa;"
		 confirm-type="search" class="searchRequest" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				articleContent: "",
				userInfo: this.getGlobalUserInfo(),
				serverUrl: this.$serverUrl,
				searchKeyWords: "",
			}
		},

		methods: {
			submit() {
				var that = this;
				uni.request({
					url: that.$serverUrl + "/article/searchArticleYANG",
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					data: {
						searchText: that.searchKeyWords,
						userId: that.userInfo.id,
						isSaveRecord: 1,
						page: 1,
					},
					success: (res) => {
						console.log(res.data);
					},
					fail: res => {
						console.log(res);
					}
				});

			}
		}
	}
</script>

<style>
	.searchRequest {
		border: #000000 solid 2px;
		border-radius: 10px;
		width: 90%;
		margin: 300px auto;
	}
</style>
