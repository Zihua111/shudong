<!-- 
chen
树洞:创建新发布的页面
2020/11/4
TODO
	*发表文章
 -->
<template>
	<!-- 页面-->
	<view class="wrapper" style="background-color: #352844;padding-top: 1px;">
		<!-- 选择发表状态区域 -->
		<view class="styleSelection" @click="changeStyle()">
			<view :class="[isShowName?'showName':'hideName']">
				<view v-if="isShowName">
					匿名
				</view>
				<view v-if="!isShowName">
					{{userInfo.userName}}
				</view>
			</view>
		</view>
		<!-- 正文发表 -->
		<view class="contentBox">
			<textarea value="" placeholder="有什么想说的就写下来吧..." v-model="value" class="text-box" style="overflow-y: scroll; padding: 10px;color: #FFFFFF" />
			<view style="color: #999999; font: 12px bold;opacity: 0.3; width: 90%; margin: 0 auto;margin-top: 25px;" >
				SELECT COLOR PREFERRED
			</view>
		</view>
		<!-- 头像颜色选择 -->
		<view class="colorSelection">
			<view class="colorWrapper" >
			 <view v-for="(oneColor,index) in colorList"  key="index" >
				<view  :style="{border: oneColor}" @click="selecteOneColor(index)" :class="[{oneColor:true},{current:curshow[index]}]">
				 </view>
			</view>
			</view>
			<view style="background-image: linear-gradient(#372A46,#221A2C);color: #999999; font: 12px bold;opacity: 0.3;;margin-top: 25px;margin: 0 auto; width: 90%;">
				SELECT RESPONDENT
			</view>
		</view>
		<!-- 确认按钮 -->
		<view class="bottom">
			<view class="button" >	
			</view>
		</view>
	</view>
</template>

<script>
	import staffLogin from '../../../components/staffLogin/staffLogin.vue'
	export default {
		data() {
			return {
				isShowName: false,//是否匿名
				value:"",//发表的文字内容
				userInfo:{//返回的用户信息
					userName:"不匿名",
				},
				styleLock:false,//用户切换样式时候的锁
				// 颜色列表
				colorList:[
					"13px solid RGBA(255, 107, 129, 1)",
					"13px solid RGBA(253, 203, 110, 1)",
					"13px solid RGBA(110, 183, 166, 1)",
					"13px solid RGBA(230, 176, 171, 1)",
					"13px solid RGBA(107, 94, 176, 1)",
					"13px solid RGBA(246, 93, 52, 1)",
				],
				currentIndex:0,//当前渲染的元素的下标
				curshow:[true,false,false,false,false,false]//当前颜色是否被选中
			}
		},
		components:{
			staffLogin,
		},
		onLoad() {
		},
		methods: {
			changeStyle(){
				// 设置用户样式选择的锁
				if (this.styleLock) {
									console.log("慢慢来");
									return;
								}
				this.styleLock = true;
				setTimeout(() => {
					this.styleLock = false;
					}, 5000);
					// 更改用户样式选择
				this.isShowName = !this.isShowName;
				this.styleLock = false;
			},
			// 设置被选中的颜色样式
			selecteOneColor(index){
				this.curshow[this.currentIndex]=false;
				this.currentIndex = index;
				this.curshow[this.currentIndex]=true;
			},
			
			// uploadArticle(){
			// 	var that = this;
			// 	var articleContent = that.value;
			// 	console.log(articleContent);
			// 	uni.request({
			// 		url:that.$serverUrl + '/article/uploadArticle',
			// 		method:'POST',
			// 		data:{
			// 			userId: '11',
			// 			articleContent:articleContent,
			// 			articleTitle: '1',
			// 		},
			// 		header: {
			// 			'content-type': 'application/x-www-form-urlencoded'
			// 		},
			// 		success: res => {
			// 			console.log('sucess');
			// 			console.log(res);
			// 		}
			// 	})
			// },
			getInfo(info){
				console.log(info)
			}
		},
		
	}
</script>

<style>
	/*  选择发表状态区域 */
	.styleSelection{
		background-color: RGBA(53, 40, 68, 1); 
		width: 90%;
		height: 23px;
		margin: 0 auto;
		margin-top: 34px;
		border-radius: 15px;
	}
	/* 匿名模式下的样式 */
	.hideName{
		box-sizing: border-box;
		height: 100%;
		padding: 4px;
		font-size: 13px;
		color: #999999;
		width: 50%;
		border-radius: 15px;
		background-color: RGBA(69, 57, 89, 1);
	}
	/* 不匿名时候的样式选择 */
	.showName{
		padding: 4px;
		font-size: 13px;
		color: #999999;
		box-sizing: border-box;
		border-radius: 15px;
		height: 100%;
		width: 50%;
		background-color: RGBA(69, 57, 89, 1);
		margin-left: 50%;
	}
	/* 发表框 */
	.contentBox{
		border-radius: 15px;
		width: 100%;
		height: 180px;
		background-color:  #352844;
		padding-top: 20px;
	}
	/* 文本键入区域 */
	.contentBox>textarea{
		width: 90%;
		height: 134px;
		opacity: 0.15;
		border-radius: 15px;
		background-color: #453959;;
		margin: 0 auto;
		color: #F8F8F8;
	}
	/* 头像颜色选择区域 */
	.colorSelection>.colorWrapper{
		display: flex;
		text-align: center;
		white-space: nowrap;
		overflow-x: scroll;
		overflow-y: hidden;
		margin: 0 auto;
		width: 90%;
		margin-top: 20px;
	}
	/* 每一个头像的颜色 */
	.oneColor{
		width: 36px;
		height: 36px;
		border-radius: 50%;
		margin-left: 10px;
		white-space: nowrap;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	/* 被选中的样式 */
	.current{
		background-color: white;
	}
	/* 底部区域 */
	.bottom{
		background-color: #453959;
		width: 100%;
		height: 300px;
	}
	/* 底部按钮 */
	.bottom>.button{
		background-image: linear-gradient(to right, #7C749F, #50456E);
		width: 170px;
		height: 45px;
		opacity: 0.48;
		margin: 0 auto;
		border-radius: 20px;
		position: relative;
		top: 150px;
	}

</style>
