<template>
	<view>
		<button type="default" @click="load()">!!</button>
		<view v-for="(item, index) in cards">
			<view> {{item.nickname}} </view>
			<view class="content">
				{{item.articleContent}}
			</view>
		</view>
	</view>


</template>

<script>
	export default {
		data() {
			return {
				data: '',
				cards: '',
			}
		},
		methods: {
			load() {
				var that = this;
				uni.request({
					url: that.$serverUrl + '/article/queryArticles',
					method: 'POST',
					data: {
						userId: that.userId,
						page: 1,
						pageSize: 10,
						queryType: 0,
						orderType: 0,
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						var result = res.data.data.rows
						this.cards = result;
						console.log(res);
					},
					fail: res => {
						console.log(res);
					}
				});
			}
		},
	}
</script>

<style>

</style>
