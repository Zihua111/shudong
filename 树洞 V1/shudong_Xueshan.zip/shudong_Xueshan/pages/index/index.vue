<!--
	Description:
	Author:
	Date:
	Version:
-->

<template>
	<view class="content">
		<view style="width: 100px;height: 100px;background-color: #007AFF;" @click="submit"></view>
		<ul>
			<li v-for="(card, index) in cards" :key="index">
				<camp-card v-bind:options="card"></camp-card>
			</li>
		</ul>
	</view>
</template>

<script>
	import uniNavBar from "@/components/uni-nav-bar/uni-nav-bar.vue"
	import CampCard from '@/components/camp-card/camp-card.vue'
	import CampTime from '@/components/camp-time/camp-time.vue'
	export default {
		data() {
			return {
				cards: [{
						userName: 'JumBox',
						content: '应该早就不叫轮滑广场了吧……也不知道 现在叫啥，就是19栋楼下那个，毕业 之后那个夏天才把雕应该早就不叫轮滑 广场了吧…… 也不知道现在叫啥，就 是19栋楼下那个，毕业之后那个夏天 才把雕应该早就不叫轮滑广场了吧……也 不知道现在叫啥，就是19栋楼下那个， 毕业之后那个夏天才把雕应该早就不叫轮 滑广场了吧……也不知道现在叫啥，就是 19栋楼下那个，毕业之后那个夏天才把 雕应该早就不叫轮滑广场了吧……',
						date: '05-20 14:30',
						like: 20,
						dislike: 20,
						reply: {
							role: "知心姐姐",
							content: "应该早就不叫轮滑广场了吧……也不知道 现在叫啥，就是19栋楼下那个，毕业 之后那个夏天才把雕应该早就不叫轮滑 广场了吧…… 也不知道现在叫啥，就 是19栋楼下那个，毕业之后那个夏天 才把雕应该早就不叫轮滑广场了吧……也 不知道现在叫啥，就是19栋楼下那个， 毕业之后那个夏天才把雕应该早就不叫轮 滑广场了吧……也不知道现在叫啥，就是 19栋楼下那个，毕业之后那个夏天才把 雕应该早就不叫轮滑广场了吧……",
						}
					},
					{
						userName: 'JumBox',
						content: '应该早就不叫轮滑广场了吧……也不知道 现在叫啥，就是19栋楼下那个，毕业 之后那个夏天才把雕应该早就不叫轮滑 广场了吧…… 也不知道现在叫啥，就 是19栋楼下那个，毕业之后那个夏天 才把雕应该早就不叫轮滑广场了吧……也 不知道现在叫啥，就是19栋楼下那个， 毕业之后那个夏天才把雕应该早就不叫轮 滑广场了吧……也不知道现在叫啥，就是 19栋楼下那个，毕业之后那个夏天才把 雕应该早就不叫轮滑广场了吧……',
						date: '05-20 14:30',
						like: 20,
						dislike: 20,
						reply: {
							role: "知心姐姐",
							content: "应该早就不叫轮滑广场了吧……也不知道 现在叫啥，就是19栋楼下那个，毕业 之后那个夏天才把雕应该早就不叫轮滑 广场了吧…… 也不知道现在叫啥，就 是19栋楼下那个，毕业之后那个夏天 才把雕应该早就不叫轮滑广场了吧……也 不知道现在叫啥，就是19栋楼下那个， 毕业之后那个夏天才把雕应该早就不叫轮 滑广场了吧……也不知道现在叫啥，就是 19栋楼下那个，毕业之后那个夏天才把 雕应该早就不叫轮滑广场了吧……",
						}
					},
					{
						userName: 'JumBox',
						content: '应该早就不叫轮滑广场了吧……也不知道 现在叫啥，就是19栋楼下那个，毕业 之后那个夏天才把雕应该早就不叫轮滑 广场了吧…… 也不知道现在叫啥，就 是19栋楼下那个，毕业之后那个夏天 才把雕应该早就不叫轮滑广场了吧……也 不知道现在叫啥，就是19栋楼下那个， 毕业之后那个夏天才把雕应该早就不叫轮 滑广场了吧……也不知道现在叫啥，就是 19栋楼下那个，毕业之后那个夏天才把 雕应该早就不叫轮滑广场了吧……',
						date: '05-20 14:30',
						like: 20,
						dislike: 20,
						reply: {
							role: "知心姐姐",
							content: "应该早就不叫轮滑广场了吧……也不知道 现在叫啥，就是19栋楼下那个，毕业 之后那个夏天才把雕应该早就不叫轮滑 广场了吧…… 也不知道现在叫啥，就 是19栋楼下那个，毕业之后那个夏天 才把雕应该早就不叫轮滑广场了吧……也 不知道现在叫啥，就是19栋楼下那个， 毕业之后那个夏天才把雕应该早就不叫轮 滑广场了吧……也不知道现在叫啥，就是 19栋楼下那个，毕业之后那个夏天才把 雕应该早就不叫轮滑广场了吧……",
						}
					},
				]
			}
		},
		components: {
			CampCard,
			CampTime,
			uniNavBar
		},
		onLoad() {
			this.test();
			console.log(getApp().globalData.text);
		},
		methods: {
			submit() {
				var me = this;
				uni.request({
					url: $serverUrl + '/article/uploadArticle',
					method: 'POST',
					data: {
						userId: me.userInfo.id,
						articleTag: finalTag,
						articleTitle: me.articleTitle,
						articleContent: me.articleContent
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						// console.log(res);
						if (res.data.status == 200) {
							if (me.imageList.length > 0) {
								const articleId = res.data.data;
								var resCount = 0;
								for (var i = 0; i < me.imageList.length; i++) {
									uploadTasks[i] = uni.uploadFile({
										url: this.$serverUrl + '/article/uploadArticleImg',
										filePath: me.imageList[i],
										name: 'file',
										formData: {
											userId: me.userInfo.id,
											articleId: articleId,
											order: i
										},
										success: uploadFileRes => {
											resCount++;
											if (resCount == me.imageList.length) {
												me.uploadSuccess();
											}
										}
									});
								}
							} else {
								me.uploadSuccess();
							}
						} else if (res.data.status == 501) {
							me.contentIllegal();
						} else {
							me.uploadFail();
						}
					},
					fail: res => {
						me.uploadFail();
					}
				});
			},
			uploadSuccess() {
				uni.showLoading({
					title: 'success',
				})
			},
			uploadFail() {
				console.log('uploadfail');
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 200upx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50upx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36upx;
		color: #8f8f94;
	}
</style>
