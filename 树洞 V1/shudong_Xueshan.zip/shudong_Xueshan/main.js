import Vue from 'vue'
import Vuex from 'vuex'
import App from './App'
import userUtil from 'common/userUtil.js' // 用户信息维护相关方法

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()

Vue.use(Vuex)
Vue.config.productionTip = false
Vue.prototype.test = function() {console.log("testing")}

 Vue.prototype.$serverUrl = "http://192.168.31.102:8080"
// Vue.prototype.$wsServerUrl = "wss://127.0.0.1:8088/ws"
// Vue.prototype.$resServerUrl = "https://nqbucket-1258460770.cos.ap-shanghai.myqcloud.com"

//Vue.prototype.$serverUrl = "https://www.checkchack.cn:8443/nottinghome"



Vue.prototype.setGlobalUserInfo = function(user) {
	// uni.setStorageSync('userInfo', user);
	userUtil.setGlobalUserInfo(user);
}

/**
 * 设置当前用户信息
 */
Vue.prototype.getGlobalUserInfo = function() {
	// var value = uni.getStorageSync('userInfo');
	// return value;
	return userUtil.getGlobalUserInfo();
}

/**
 * 清空当前用户信息
 */
Vue.prototype.removeGlobalUserInfo = function() {
	// uni.removeStorageSync('userInfo');
	userUtil.removeGlobalUserInfo();
}

/**
 * Timestamp 渲染
 * @param {Object} timediff
 */
Vue.prototype.timeDeal = function(timediff) {
	timediff = new Date(timediff);
	var parts = [timediff.getFullYear(), timediff.getMonth() + 1, timediff.getDate(), app.TwoDigit(timediff.getHours()), app.TwoDigit(timediff.getMinutes()),
		timediff.getSeconds()
	];
	var oldTime = timediff.getTime();
	var now = new Date();
	var newTime = now.getTime();
	var milliseconds = 0;
	var timeSpanStr;
	milliseconds = newTime - oldTime;
	if (milliseconds <= 1000 * 60 * 1) {
		timeSpanStr = app.$store.state.lang.justNow;
	} else if (1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
		timeSpanStr = Math.round((milliseconds / (1000 * 60))) + app.$store.state.lang.minsAgo;
	} else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
		timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + app.$store.state.lang.hoursAgo;
	} else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 15) {
		timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + app.$store.state.lang.daysAgo;

	} else if (milliseconds > 1000 * 60 * 60 * 24 * 15 && parts[0] == now.getFullYear()) {
		timeSpanStr = parts[1] + '-' + parts[2] + ' ' + parts[3] + ':' + parts[4];
	} else {
		timeSpanStr = parts[0] + '-' + parts[1] + '-' + parts[2] + ' ' + parts[3] + ':' + parts[4];
	}
	return timeSpanStr;
}

/**
 * 时间显示格式化 eg. 13:01
 */
Vue.prototype.TwoDigit = function(digit){
	if(0 < digit && digit <= 9){
		digit = "0" + digit
	}
	return digit;
}