<template>
	<view style="width: 400px;height: 400px;position: fixed;background-color: #6A6A6A;top:50;left:0">
		<input v-model="articleContent" />
<!-- 		<button @click="submit">发表</button>
 -->	</view>
</template>

<script>
	export default {
		data() {
			return {
				articleContent: "",
				userInfo: this.getGlobalUserInfo(),
				serverUrl:this.$serverUrl,
			}
		},
		methods: {
			submit() {
				var that = this;
				uni.request({
					url: that.serverUrl + '/article/uploadArticle',
					method: 'POST',
					data: {
						userId: that.userInfo.id,
						articleTag: '#000000',
						articleTitle: '58',
						articleContent: that.articleContent,
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						console.log(res);
					}
				});
			}
		},
		mounted() {
			var that = this;
			uni.request({
				url: that.$serverUrl + '/article/queryArticles',
				method: 'POST',
				data: {
					page: 1,
					// pageSize: '',
					userId: that.userInfo.id,
					queryType: '0',
					orderType: '0',
					selectedTag: ""
				},
				header: {
					'content-type': 'application/x-www-form-urlencoded'
				},
				success: res => {
					console.log('success');
					console.log(res);
					//that.articleList = res.data.data.rows;
					//that.totalPage = res.data.data.total;
				},
				fail: res => {
					
				}
			});
		}
	}
</script>

<style>
</style>
