<!--
 用户登录卡片
 Chen
 2020/11/9
 
 -->
<template>
	<view>
		<view class="loginWrapper" v-show="!isLogin">
			<view class="loginCard">
				欢迎来到树洞</br>
				在这里</br>
				你是自由的</br>
				让树洞</br>
				成为你的声音</br>
			<camp-login :loginText="'登录'" :loginStyle=" 'height:40px;width:100px;line-height:40px;'" @loginSuccess="successLogin"
			 @loginFail="failLogin"></camp-login>
			 </view>
		</view>
	</view>
</template>

<script>
	import CampLogin from '../camp-login/camp-login.vue'
	export default {
		data() {
			return {
				isLogin: false,
			}
		},
		components: {
			CampLogin,
		},
		methods: {
			successLogin(){
				console.log("oklogin");
				this.isLogin = true;
			},
			failLogin(){
				console.log("nologin");
				this.isLogin = false;
			}
		}
	}
</script>

<style>
	.loginWrapper{
		box-sizing: border-box;
		position: fixed;
		top:0px;
		width: 100%;
		height: 100%;
		z-index: 100;
		background-color: rgba(0,0,0,.5);
	}
	.loginCard{
		box-sizing: border-box;
		padding: 10px;
		height: 26%;
		width: 90%;
		position: relative;
		background-color: #515151;
		color: #FFFDEF;
		margin: 0 auto;
		top: 210px;
		border-radius: 15px;
	}
</style>
