<!-- 
树洞后台主页卡片
chen
2020/11/1

 -->

<template>
	<view>
		<view class="wrapper" @click="showPage(1)">
			<!-- 用户信息 -->
			<view class="userInfo">
				<!-- 用户头像 -->
				<view class="userImg" style="background-color: #DBA503;">
					<image :src="cardInfo.userImg" mode="aspectFill"></image>
				</view>
				<!-- 用户名 -->
				<view class="userName">
					{{cardInfo.nickname}}
				</view>
			</view>
			<!-- 文章显示 -->
			<view class="contentText" :style="userColor">
				{{cardInfo.articleContent}}
			</view>

		</view>
		<!-- 底部显示点赞、时间的区域 -->
		<view class="infoBox">
			<view class="timeLine" style="margin-right: 130px;">
				{{timeDeal(cardInfo.createDate).date}} {{timeDeal(cardInfo.createDate).time}}
			</view>
			<view class="iconBox" style="display: flex; margin: 5px;">
				<view class="icon-comment" @click="replyShow(1)">
					回复
				</view>
			</view>
		</view>
		<!-- 点击时候显示的弹窗 -->
		<view class="popWrapper" v-show="isShow" @click="showPage(0)" style="z-index: 100;">
			<view class="popBox">
				<!-- 用户信息 -->
				<view class="userInfo">
					<!-- 用户头像 -->
					<view class="userImg" style="background-color: #DBA503;">
						<image :src="cardInfo.userImg" mode="aspectFill"></image>
					</view>
					<!-- 用户名 -->
					<view class="userName">
						{{cardInfo.nickname}}
					</view>
				</view>
				<!-- 文章显示 -->
				<view class="contentText" :style="userColor">
					{{cardInfo.articleContent}}
				</view>
				<view style="display: flex;width: 80%;">
					<view class="timeLine" style="margin-right: 130px;">
						{{timeDeal(cardInfo.createDate).date}} {{timeDeal(cardInfo.createDate).time}}
					</view>
				</view>

			</view>

			<!-- 有回复时候会弹出的回复内容 -->
			<view class="answerBox" v-if="cardInfo.commentNum==1" @click="showPage(0)">
				<view class="userInfo">
					<!-- 用户头像 -->
					<view class="userImg" style="background-color: #DBA503;">
						<image :src="cardInfo.userImg" mode="aspectFill"></image>
					</view>
					<view class="userName" style="color: #222222;">
						{{userComment.nickname}}
					</view>
				</view>
				<view class="contentText" style="color: #222222;">
					{{userComment.comment}}
				</view>
			</view>
		</view>

		<!--发表回复弹窗 -->
		<view class="replywrapper" v-show="isShowReplyPop">
			<view class="replyBox">
				<view class="top-bar">
					<view class="emjio iconfont icon-smile-wink-alt"> </view>
					<view class="delete iconfont icon-multiple" @click="replyShow(0)">取消</view>
				</view>
				<view>
				</view>
				<textarea v-model="value" class="text-box" style="overflow-y: scroll;" value="" />
				<view class="bottom">
					<!-- 回复 -->
							<view class="submitButton" @click="submitComment" @staffInfo="getStaffInfo">
								发 布
							</view>
						</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isShow: false,
				isShowReplyPop: false,
				value:"",
				userComment:{},
				staffInfoList:{},
			}
		},
		props: {
			cardInfo: {},
			staffInfo:{},
		},
		
		created() {
			this.getComment();
			console.log(this.cardInfo);
			console.log("qq");
			console.log(this.staffInfo);
		},
		
		methods: {
			// 修改时间格式
			timeDeal(timestamp) {
				let date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
				let D = date.getDate() + ' ';
				let h = date.getHours() + ':';
				let m = date.getMinutes();
				return {
					date: M + D,
					time: h + m
				};
			},
			showPage(a) {
				this.isShow = a;
			},
			replyShow(a){
				this.isShowReplyPop = a;
			},
			//评论发表
			submitComment(){
				var that = this;
				var commentValue = that.value;
				console.log(commentValue);
				uni.request({
					url: that.$serverUrl + '/social/saveComment',
					method: 'POST',
					data: {
						fromUserId: that.staffInfo.id,
						toUserId: that.cardInfo.userId,
						targetType: "ARTICLE",
						targetId:that.cardInfo.id,
						comment: commentValue,
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => { 
						console.log('success');
						console.log(res);
						that.cardInfo.answerName = this.fromUserId;
						this.replyShow(0);
						},
					fail: res => {
							console.log("failed");
						}
				})
			},
			
			//获取文章评论
			getComment() {
				console.log("comment",this.cardInfo.targetId);
				var that = this;
				uni.request({
					url: that.$serverUrl + '/social/getMainComments',
					method: 'POST',
					data: {
						type: 0,
						targetType: "ARTICLE",
						targetId: that.cardInfo.id,
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						console.log('getComment');
						console.log(res);
						that.userComment = res.data.data.rows[0];
					},
					fail: res => {
						console.log("false")
					}
				});
			},
			created(){
				console.log("子组件接受");
				console.log(this.staffInfo);
			},
			
		}
	}
</script>

<style>
	/* 正文卡片 */
	.wrapper {
		margin: 0 auto;
		width: 90%;
		background: #444444;
		border-radius: 15px 15px 0px 0px;
	}

	/* 设置用户信息一栏的样式 */
	.userInfo {
		display: flex;
		flex-direction: row;
	}

	/* 设置用户头像的样式 */
	.userInfo>.userImg {
		margin: 15px;
		width: 15px;
		height: 15px;
		border-radius: 50%;

	}

	/* 设置用户名字 */
	.userInfo>.userName {
		font-size: 11px;
		height: 20px;
		line-height: 28px;
		margin-top: 8px;
		margin-bottom: 10px;
		/* 设置用户名文字样式 */
		width: 285px;
		height: 21px;
		font-weight: bold;
		color: #888888;
		line-height: 34px;

	}

	/* 文字内容区 */
	.contentText {
		word-break: break-word;
		margin: 0 auto;
		width: 90%;
		/* 设置卡片显示的文字样式 */
		font-size: 12px;
		font-weight: bold;
		color: #E2E2E2;
		line-height: 38px;
		padding: 5px;
	}

	.infoBox {
		background-image: radial-gradient(#6B6B6B,#84796C);
		display: flex;
		width: 80%;
		border-radius: 0px 0px 15px 15px;
		margin: 0 auto;
		margin-bottom: 10px;
	}
	.timeLine {
		/* 时间文字显示 */
		font-size: 10px;
		font-weight: bold;
		color: #888888;
		line-height: 34px;
		padding-top: 5px;
		padding-left: 5px;
	}
	/* 点赞的字体图标 */
	.infoBox>.iconBox>view {
		margin-left: 20px;
	}
	/* 弹窗 */
	.popWrapper,.replywrapper{
		box-sizing: border-box;
		position: fixed;
		top: 0px;
		width: 100%;
		height: 100%;
		z-index: 100;
		background-color: rgba(0, 0, 0, .5);
	}
	/* 弹窗的正文区域 */
	.popBox {
		box-sizing: border-box;
		padding: 10px;
		width: 85%;
		left: 7.5%;
		right: auto;
		border-radius: 15px 15px 0px 0px;
		margin: 0 auto;
		margin-top: 100px;
		background-color: #444444;
	}
	/* 弹窗的评论区域 */
	.answerBox {
		width: 75%;
		background-image: radial-gradient(#6B6B6B,#84796C);
		border-bottom-left-radius: 12px;
		border-bottom-right-radius: 12px;
		margin: 0 auto;
		margin-top: -5px;
	}
/* 回复弹窗 */
	.replyBox{
		width: 85%;
		height: 255px;
		background-color: #515151;
		border-radius: 15px;
		margin: 0 auto;
		display: flex;
		flex-direction: column;
		margin: 300upx auto;
		vertical-align: center;
		}
	
	/* 设置上方选择框 */
		.top-bar {
			height: 45px;
		}	
		.emjio {
			float: left;
			height: 100%;
			margin-left: 52upx;
		}
		.delete {
			float: right;
			height: 100%;
			margin-right: 39upx;
		}
			
		/* 设置文本输入框 */
		.text-box {
			box-sizing: border-box;
			width: 95%;
			height: 200px;
			background: #6A6A6A;
			border-radius: 10px;
			margin: 0 auto;
			margin-bottom: 10px;
			padding: 15px;
		}
	
		/* 下方发布框 */
		.bottom {
			width: 100%;
			height: 34px;
			background: #FDD041;
			border-radius: 0px 0px 15px 15px;
			margin-top: 15px;
			display: flex;
			justify-content: center;
			margin: 0 auto;
			
		}
	
		/* 发布按钮 */
		.bottom>.submitButton {
			width: 50px;
			height: 19px;
			font-size: 19px;
			font-weight: bold;
			color: #363636;
			line-height: 31upx;
			margin: 0 auto;
			margin-top: 10px;
		}
	</style>
</style>
