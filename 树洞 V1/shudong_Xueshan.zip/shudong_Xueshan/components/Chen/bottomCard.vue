<!-- 
底部组件
 -->
<template>
	<view>
		<!-- //底部半透明框 -->
		<view class="bottomBar"@click="goCreatePage" @longpress="goBackIndex">
			<!-- //发布按钮 -->
			<view class="createButton">

			</view>

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		methods:{
			goCreatePage() {
				uni.navigateTo({
					url:'../createPage/createPage'
				})
			},
			goBackIndex(){
				uni.navigateTo({
					url:'../back-index/back-index'
				})
			}
		}
	}
</script>

<style>
	/* 底部区域样式 */
	.bottomBar {
		position: fixed;
		bottom: 0px;
		background-color: #515151;
		width: 100%;
		height: 70px;
		opacity: 0.5;
		border-top-left-radius: 20px;
		border-top-right-radius: 20px;
	}

	/* 发布按钮样式 */
	.bottomBar>.createButton {
		position: relative;
		width: 60px;
		height: 60px;
		border-radius: 50%;
		background-color: #FFFFFF;
		border: 25px #515151 solid;
		left: 137px;
		bottom: 25px;
	}
</style>
