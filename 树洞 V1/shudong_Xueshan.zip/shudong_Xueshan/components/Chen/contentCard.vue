<!-- 
Description: 树洞项目主页卡片组件
Author: Chen
Date：2020/10/29
version
 -->

<template>
	<view>
		<!-- 设置整个显示卡片 -->
		<view class="wrapper" style="z-index: -100;" @click="showPage">
			<!-- 用户信息 -->
			<view class="userInfo">
				<!-- 用户头像 -->
				<view class="userImg" style="background-color: #0077AA;">
					<image :src="cardInfo.userImg" mode="aspectFill"></image>
				</view>

				<!-- 用户名 -->
				<view class="userName">
					{{cardInfo.userName}}
				</view>
			</view>
			<!-- 文章显示 -->
			<view class="contentText" :style="userColor">
				{{cardInfo.contentText}}
			</view>
			<!-- 时间 -->
			<view class="timeDisplay">
				{{cardInfo.timeDisplay}}
			</view>
		</view>
		<!-- 若有回复则显示的效果 -->
		<view class="answerSign" v-if="cardInfo.isAnswered" @click="showPage" style="height: 36px; z-index: -100;"></view>
		<!-- 点击时候弹出的详情框 -->
		<view class="popWrapper" v-show="isShow" @click="hidePage" style="z-index: 100;">
			<view class="popBox">
				<view v-show="isShow">
					<view class="userInfo">
						<view class="userImg" style="background-color: #0077AA;">
							<image :src="cardInfo.userImg" mode="aspectFill"></image>
						</view>
						<view class="userName">
							{{cardInfo.userName}}
						</view>
					</view>
					<view class="contentText">
						{{cardInfo.contentText}}
					</view>
					<view class="timeDisplay">
						{{cardInfo.timeDisplay}}
					</view>
				</view>
				
			</view>
			<!-- 有回复时候会弹出的回复内容 -->
			<view class="answerBox" v-show="cardInfo.isAnswered" @click="showPage">
				<view class="userInfo">
					<view class="userImg" style="background-color: #0077AA;">
						<image :src="cardInfo.answerImg" mode="aspectFill"></image>
					</view>
					<view class="userName" style="color: #222222;">
						{{userComment.nickname}}
					</view>
				</view>
				<view class="contentText" style="color: #222222;">
					{{userComment.comment}}
				</view>
			</view>
		</view>
	</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				isShow: false,// 是否显示弹窗的变量
				userComment:{},
			}
		},
		props: {
			cardInfo: {},
		},
		mounted() {
			console.log(this.cardInfo);
			this.getComment();
		},
		
		methods: {
			// 显示弹窗
			showPage() {
				this.isShow = true;
			},
			// 隐藏弹窗
			hidePage() {
				this.isShow = false;
			},
			//获取文章评论
			getComment() {
				console.log("comment",this.cardInfo.targetId);
				var that = this;
				uni.request({
					url: that.$serverUrl + '/social/getMainComments',
					method: 'POST',
					data: {
						type: 0,
						targetType: "ARTICLE",
						targetId: that.cardInfo.targetId,
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						console.log('getComment');
						console.log(res);
						that.userComment = res.data.data.rows[0];
					},
					fail: res => {
						console.log("false")
					}
				});
			},

		}


	}
</script>

<style>
	/* 设置整个卡片的外围 */
	.wrapper {
		width: 90%;
		margin: 0 auto;
		background-color: #515151;
		border-radius: 15px;
		margin-bottom: 20px;

	}

	/* 设置用户信息一栏的样式 */
	.userInfo {
		display: flex;
		flex-direction: row;
	}

	/* 设置用户头像的样式 */
	.userInfo>.userImg {
		margin: 15px;
		width: 38px;
		height: 38px;
		border-radius: 50%;

	}

	/* 设置用户名字 */
	.userInfo>.userName {
		font-size: 11px;
		height: 28px;
		line-height: 28px;
		margin-top: 15px;
		margin-bottom: 15px;
		/* 设置用户名文字样式 */
		width: 285px;
		height: 21px;
		font-weight: bold;
		color: #888888;
		line-height: 34px;

	}

	/* 用户选择的颜色样式 */
	.userInfo>.moodColor {
		width: 6px;
		height: 100px;
	}

	/* 文字内容区 */
	.contentText {
		word-break: break-word;
		margin: 0 auto;
		width: 90%;
		margin-bottom: 8px;
		/* 设置卡片显示的文字样式 */
		font-size: 12px;
		font-weight: bold;
		color: #E2E2E2;
		line-height: 38px;

	}

	/* 时间显示区域的样式 */
	.timeDisplay {
		width: 90%;
		margin: 0 auto;
		font-size: 10px;
		font-weight: bold;
		color: #888888;
		line-height: 34px;

	}
	/* 有回复的正文卡片样式 */
	.answerSign {
		width: 80%;
		background-color: #646464;
		margin: 0 auto;
		margin-top: -20px;
		margin-bottom: 3px;
		border-bottom-left-radius: 12px;
		border-bottom-right-radius: 12px;

	}
	/* 点击卡片的弹窗 */
	.popWrapper{
		box-sizing: border-box;
		position: fixed;
		top:0px;
		width: 100%;
		height: 100%;
		z-index: 100;
		background-color: rgba(0,0,0,.5);
	}
	/*弹窗正文样式*/
	.popBox {
		padding: 0px;
		width: 85%;
		left: 7.5%;
		right: auto;
		background-color: #646464;
		border-radius: 15px;
		margin: 0 auto;
		margin-top: 100px;
	}
	/* 弹窗评论样式 */
	.answerBox{
		width: 70%;
		background-color: #828282;
		border-bottom-left-radius: 12px;
		border-bottom-right-radius: 12px;
		margin: 0 auto;
	}
</style>
