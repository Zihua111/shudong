<template>
	<view>
		<view class="about-card">
			<view class="post">
				<view class="head">
					<view class="head-text">{{options.title}}</view>
				</view>
				<view class="content">
					<view class="title-text">{{options.subTitle}}</view>
					<view class="content-text">{{options.content}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'CampCard',
		props: {
			options: {
				title: {
					type: String,
					default: 'unknown'
				},
				subTitle: {
					type: String,
					default: 'unknown'
				},
				content: {
					type: String,
					default: 'unknown'
				},
			},
		},
	}
</script>

<style>
	@import './about-card.css';
/* 	#@#  不要引入CSS, 因为目前不涉及公用CSS, 足够公用的会根目录挂载为全局组件,单文件规范就是为了局部化各种元素,CSS不要分离出去
 */</style>
