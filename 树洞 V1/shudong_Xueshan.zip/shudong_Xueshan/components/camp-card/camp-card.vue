<!--
	Description: card for post and reply
	Author: Desmond
	Date:
	Version:
-->

<template>
	<view class="camp-card">
		<!-- 文章主体 -->
		<view class="post">
			<!-- 文章头部 -->
			<view class="head">
				<image class="pentagon" src="../../static/image/pentagon.png"></image>
				<view class="head-text">{{option.userId}}</view>
			</view>
			<!-- 文章内容 -->
			<view class="content">
				<view class="content-text">{{option.articleContent}}</view>
			</view>
		</view>
		<!-- 抽出部分 -->
		<view class="foot">
			<!-- 回复主体 -->
			<view class="foot-reply" v-if="showReply">
				<!-- 回复头部 -->
				<view class="foot-head">
					<image class="pentagon" src="../../static/image/pentagon.png"></image>
					<view class="head-text">{{option.reply.role}}</view>
				</view>
				<!-- 回复内容 -->
				<view class="foot-content">
					<view class="content-text">{{option.reply.content}}</view>
				</view>
				<!-- 提交回复表单 -->
				<form class="foot-form" @submit="submit">
					<textarea class="foot-textarea" show-confirm-bar="true" adjust-position="true" v-model="reply"></textarea>
					<button form-type="submit" class="button-submit" hover-class="button-submit-hover">回复</button>
				</form>
			</view>
			<!-- 附加信息 -->
			<view class="foot-text">
				<view>{{option.date}}</view>
				<view class="foot-text-optional">
					<view class="foot-text-like">
						<image class="thumb" src="../../static/image/thumb-up.png"></image>
						{{option.like}}
					</view>
					<view class="foot-text-dislike">
						<image class="thumb" src="../../static/image/thumb-down.png"></image>
						{{option.dislike}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'CampCard',
		props: {
			option: {
				articleContent: {
					type: String,
					default: ''
				},
				userId: {
					type: String,
					default: ''
				},
				likeNum: {
					type: String,
					default: ''
				},
				dislikeNum: {
					type: String,
					default: ''
				},
				commentNum: {
					type: String,
					default: ''
				}
			},
		},
		data() {
			return {
				// 文章获取
				userInfo: this.getGlobalUserInfo(),
				serverUrl:this.$serverUrl,
				// 回复内容
				reply: "",
			}
		},
		// 时间戳转换
		computed: {
			date: function() {
				var date = new Date(this.options.createDate);
				return date.toLocaleDateString().replace(/\//g, "-") + " " + date.toTimeString().substr(0, 8);
			}
		},
		methods: {
			submit() {
				var that = this;
				uni.request({
					url: that.serverUrl + '/article/uploadArticle',
					method: 'POST',
					data: {
						userId: that.userInfo.id,
						articleTag: '#000000',
						articleTitle: '58',
						articleContent: that.reply,
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					success: res => {
						console.log(res);
						console.log(that.reply);
					}
				});
			}
		}
	}
</script>

<style scoped>
	@import url('./camp-card.css');
</style>
