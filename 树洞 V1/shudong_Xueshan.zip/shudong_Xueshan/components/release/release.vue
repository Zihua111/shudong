<template>
	<view class="content">
		<view class="blank-top"></view>
		<view class="release">
			<view class="release-header">
				<image class="smile" src="../../static/image/smile.png"></image>
				<image class="close" src="../../static/image/close.png"></image>
			</view>
			<view class="inner-content"></view>
		</view>
		<button class="bottom">发&nbsp;&nbsp;&nbsp;布</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style scoped>
	.content {
		width: 375px;
		height: 666px;
		background: #2F2F2F;
		opacity: 0.8;
	}

	.blank-top {
		width: 100%;
		height: 165px;
	}

	.release {
		width: 321px;
		height: 218.5px;
		background: #515151;
		border-radius: 15px 15px 0 0;
		margin: auto;
	}

	.release-header {
		height: 40px;
		width: 321px;
	}

	.smile {
		height: 25px;
		width: 25px;
		margin-top: 7.5px;
		margin-left:20px;
	}

	.close {
		height: 25px;
		width: 25px;
		margin-top: 7.5px;
		margin-left:230px;
	}

	.inner-content {
		width: 300px;
		height: 161px;
		margin: auto;
		background-color: #6A6A6A;
		border-radius: 10px;
	}

	.bottom {
		width: 321px;
		height: 40px;
		border-radius: 0 0 15px 15px;
		margin: auto;
		background: #FDD041;
		font-size: 18px;
		line-height: 40px;
	}
</style>
